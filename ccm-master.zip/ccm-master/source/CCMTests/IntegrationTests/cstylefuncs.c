
void
  added(button, selection_box, ignore)
Widget 	button, selection_box;
caddr_t ignore;
{
}

void
  new_cfg_record(button, selection_box, ignore)
Widget 	button, selection_box;
caddr_t ignore;
{
}

void
  edit_cfg_record(button, selection_box, ignore)
Widget 	button, selection_box;
caddr_t ignore;
{
}
