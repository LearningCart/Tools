﻿using System;
using System.Collections.Generic;
using System.Text;

namespace vsCCM
{
  public class AbortException : Exception
  {
  }

  public class IgnoreException : Exception
  {
  }
}
