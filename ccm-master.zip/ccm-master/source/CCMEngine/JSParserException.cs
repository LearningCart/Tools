﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CCMEngine
{
  public class JSParserException : Exception
  {
    public JSParserException(string message) : base(message)
    {

    }
  }
}
